package com.xs.youtu.common;
/** 
 * 常量 
 * @author 小帅丶 
 * @类名称  YouTuAppContants 
 * @remark  
 * @date  2018-03-22
 */  
public class YouTuAppContants {  
    public static String AppID = "你自己的AppID";  
    public static String SecretID = "你自己的SecretID";  
    public static String SecretKey = "你自己的SecretKey";  
    public static String userQQ = "你自己的userQQ";  
}  