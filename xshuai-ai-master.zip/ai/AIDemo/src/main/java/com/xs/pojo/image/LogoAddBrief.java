package com.xs.pojo.image;
/**
 * LOGO入库brief对象 根据实际情况编写 并不一样需要对象哦
 * @author 小帅丶
 *
 */
public class LogoAddBrief {
	public String name;
	public String code;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
