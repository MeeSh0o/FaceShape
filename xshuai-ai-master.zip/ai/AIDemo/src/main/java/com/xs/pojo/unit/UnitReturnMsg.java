package com.xs.pojo.unit;
/**
 * 临时测试用
 * @author 小帅丶
 *
 */
public class UnitReturnMsg {
	private String action_id;
	private String say;
	private String session_id;
	public String getAction_id() {
		return action_id;
	}
	public void setAction_id(String action_id) {
		this.action_id = action_id;
	}
	public String getSay() {
		return say;
	}
	public void setSay(String say) {
		this.say = say;
	}
	public String getSession_id() {
		return session_id;
	}
	public void setSession_id(String session_id) {
		this.session_id = session_id;
	}
	
}
