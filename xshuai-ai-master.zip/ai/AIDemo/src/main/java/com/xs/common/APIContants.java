package com.xs.common;
/**
 * 相关密钥
 * @author 宗潇帅
 * @date  2017-5-26上午10:49:13
 */
public class APIContants {
	//百度人脸识别应用id
	public static final String APPID = "替换成自己相应的值";
	//百度人脸识别应用apikey
	public static final String API_KEY = "替换成自己相应的值";
	//百度人脸识别应用sercetkey
	public static final String SERCET_KEY = "替换成自己相应的值";
	//百度人脸识别token 有效期一个月
	public static final String TOKEN = "根据APIKEY & SERCERKEY生成ACCESSTOKEN";
	
	//百度文字识别应用id
	public static final String IDCARD_APPID = "替换成自己相应的值";
	//百度文字识别应用apikey
	public static final String IDCARD_API_KEY = "替换成自己相应的值";
	//百度文字识别应用sercetkey
	public static final String IDCARD_SERCET_KEY = "替换成自己相应的值";
	//百度文字识别token 有效期一个月
	public static final String IDCARD_TOKEN = "根据APIKEY & SERCERKEY生成ACCESSTOKEN";
	
	//百度语音应用id
	public static final String VOICE_APPID = "替换成自己相应的值";
	//百度语音应用apikey
	public static final String VOICE_API_KEY = "替换成自己相应的值";
	//百度语音应用sercetkey
	public static final String VOICE_SERCET_KEY = "替换成自己相应的值";
	public static final String VOICE_TOKEN = "根据APIKEY & SERCERKEY生成ACCESSTOKEN";

	//百度语音应用id
	public static final String NLP_APPID = "替换成自己相应的值";
	//百度语音应用apikey
	public static final String NLP_API_KEY = "替换成自己相应的值";
	//百度语音应用sercetkey
	public static final String NLP_SERCET_KEY = "替换成自己相应的值";
	public static final String NLP_TOKEN = "根据APIKEY & SERCERKEY生成ACCESSTOKEN";
	
	
}
