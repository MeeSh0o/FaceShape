package com.xs.pojo.unit;
/**
 * UnitUtterance
 * @author 小帅丶
 *
 */
public class UnitUtterance {
	private Integer scene_id;
	private String query;
	private String session_id;
	
	public Integer getScene_id() {
		return scene_id;
	}
	public void setScene_id(Integer scene_id) {
		this.scene_id = scene_id;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSession_id() {
		return session_id;
	}
	public void setSession_id(String session_id) {
		this.session_id = session_id;
	}
	
}
