#微信小程序-微信端源代码
#pages 所有的页面文件夹
#pages-chram 腾讯优图-人脸检测
#腾讯优图接入官网文档：http://open.youtu.qq.com/welcome/developer
#pages-face  百度大脑-人脸检测
#百度大脑接入官网文档：http://ai.baidu.com/docs#/Begin/top
#pages-index、log、sample quick start带的sample 没用
#image 一些需要的图片
![小程序专属二维码](https://www.xsshome.cn/xcx.jpg "小程序专属二维码")
![小程序截图](https://www.xsshome.cn/index.png "小程序截图")